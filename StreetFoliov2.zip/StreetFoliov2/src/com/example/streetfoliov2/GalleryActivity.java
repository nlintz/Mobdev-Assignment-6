package com.example.streetfoliov2;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class GalleryActivity extends Activity {
	int i =0;
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
    }

    public void changePic(View V){
        ImageView img = (ImageView) findViewById(R.id.gallery);
    	int[] resId = {R.drawable.pic1,R.drawable.pic2,R.drawable.pic3};
    	int nextPic = resId[(this.i+1)%3];
    	System.out.println(this.i);
    	img.setImageResource(nextPic);
    	this.i++;
    }
    

}
